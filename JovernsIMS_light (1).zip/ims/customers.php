<?php require_once 'header.php'; checkAdmin();
$msg=$_GET['msg']??'';
if($_SERVER['REQUEST_METHOD']==='POST'){csrf_verify();
  $a=$_POST['action']??'';
  $n=esc($conn,$_POST['customer_name']??''); $c=esc($conn,$_POST['contact']??'');
  $em=esc($conn,$_POST['email']??''); $ad=esc($conn,$_POST['address']??'');
  $ct=esc($conn,$_POST['client_type']??'Walk-in'); $pt=esc($conn,$_POST['payment_terms']??'COD');
  if($a==='add'){mysqli_query($conn,"INSERT INTO customers(customer_name,contact,email,address,client_type,payment_terms)VALUES('$n','$c','$em','$ad','$ct','$pt')");
    header('Location: customers.php?msg=✅ Client added.'); exit;}
  if($a==='edit'){$id=(int)$_POST['id'];
    mysqli_query($conn,"UPDATE customers SET customer_name='$n',contact='$c',email='$em',address='$ad',client_type='$ct',payment_terms='$pt' WHERE id=$id");
    header('Location: customers.php?msg=✅ Updated.'); exit;}
}
if(isset($_GET['del'])){$id=(int)$_GET['del']; mysqli_query($conn,"DELETE FROM customers WHERE id=$id"); header('Location: customers.php?msg=🗑️ Deleted.'); exit;}
$cust=mysqli_query($conn,"SELECT * FROM customers ORDER BY customer_name");
$edit=null;if(isset($_GET['edit']))$edit=mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM customers WHERE id=".(int)$_GET['edit']));
?>
<div class="page-header">
  <div class="page-title-block"><h1>👥 Clients</h1><p>Manage client records and contact information.</p></div>
</div>
<?php if($msg): ?><div class="alert alert-success"><?=e($msg)?></div><?php endif; ?>
<div class="card">
  <div class="card-head"><div class="card-head-icon"><?=$edit?'✏️':'➕'?></div>
    <div><div class="card-head-title"><?=$edit?'Edit: '.e($edit['customer_name']):'Add New Client'?></div>
    <div class="card-head-sub">Fill in client contact details</div></div>
  </div>
  <div class="card-body">
  <form method="post">
    <?=csrf_field()?>
    <input type="hidden" name="action" value="<?=$edit?'edit':'add'?>">
    <?php if($edit): ?><input type="hidden" name="id" value="<?=$edit['id']?>"><?php endif; ?>
    <div class="field-grid">
      <div class="field"><label>Client Name *</label><input type="text" name="customer_name" required placeholder="Full name / Company" value="<?=e($edit['customer_name']??'')?>"></div>
      <div class="field"><label>Contact Number</label><input type="text" name="contact" placeholder="09xx-xxx-xxxx" value="<?=e($edit['contact']??'')?>"></div>
      <div class="field"><label>Email</label><input type="email" name="email" placeholder="email@example.com" value="<?=e($edit['email']??'')?>"></div>
      <div class="field"><label>Address</label><input type="text" name="address" placeholder="City, Province" value="<?=e($edit['address']??'')?>"></div>
      <div class="field"><label>Client Type</label>
        <select name="client_type">
          <?php foreach(['Walk-in','Regular','Business','Government'] as $t): ?>
          <option <?=($edit&&$edit['client_type']===$t)?'selected':''?>><?=$t?></option>
          <?php endforeach; ?>
        </select></div>
      <div class="field"><label>Payment Terms</label>
        <select name="payment_terms">
          <?php foreach(['COD','30 days','60 days','Credit','DP+Balance'] as $t): ?>
          <option <?=($edit&&$edit['payment_terms']===$t)?'selected':''?>><?=$t?></option>
          <?php endforeach; ?>
        </select></div>
    </div>
    <div class="card-foot" style="padding:0;border:none;background:none;margin-top:8px;">
      <button type="submit" class="btn">💾 <?=$edit?'Update':'Save Client'?></button>
      <?php if($edit): ?><a href="customers.php" class="btn btn-ghost">Cancel</a><?php endif; ?>
    </div>
  </form>
  </div>
</div>
<h3 style="margin-bottom:12px;">📋 Client List</h3>
<div class="table-wrap"><table><thead><tr><th>Name</th><th>Contact</th><th>Email</th><th>Address</th><th>Type</th><th>Terms</th><th>Since</th><th>Actions</th></tr></thead>
<tbody>
<?php while($c=mysqli_fetch_assoc($cust)): ?>
<tr>
  <td><strong><?=e($c['customer_name'])?></strong></td>
  <td><?=e($c['contact']??'—')?></td>
  <td style="font-size:12px"><?=e($c['email']??'—')?></td>
  <td style="font-size:12px;color:var(--txt2)"><?=e($c['address']??'—')?></td>
  <td><span class="badge b-steel"><?=e($c['client_type'])?></span></td>
  <td><span class="badge b-muted"><?=e($c['payment_terms'])?></span></td>
  <td style="font-size:12px;color:var(--txt3)"><?=date('M j, Y',strtotime($c['created_at']))?></td>
  <td style="white-space:nowrap">
    <a href="?edit=<?=$c['id']?>" class="btn btn-ghost btn-xs">✏️</a>
    <a href="?del=<?=$c['id']?>" class="btn btn-danger btn-xs" onclick="return confirm('Delete client?')">🗑️</a>
  </td>
</tr>
<?php endwhile; ?>
</tbody></table></div>
<?php require_once 'footer.php'; ?>
