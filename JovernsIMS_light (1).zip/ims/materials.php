<?php require_once 'header.php'; checkAdmin();
$msg=$_GET['msg']??'';
if($_SERVER['REQUEST_METHOD']==='POST'){csrf_verify();
  $a=$_POST['action']??'';
  $n=esc($conn,$_POST['material_name']??'');
  $s=esc($conn,$_POST['supplier']??'');
  $p=max(0,(float)($_POST['price']??0));
  $img='';
  if($a==='add'){
    if(isset($_FILES['img'])&&$_FILES['img']['error']===0){
      $ext=strtolower(pathinfo($_FILES['img']['name'],PATHINFO_EXTENSION));
      if(in_array($ext,['jpg','jpeg','png','gif','webp'])){$img='uploads/'.uniqid('mat_',true).'.'.$ext;move_uploaded_file($_FILES['img']['tmp_name'],$img);}
    }
    mysqli_query($conn,"INSERT INTO materials(material_name,supplier,price,image)VALUES('$n','$s',$p,'$img')");
    header('Location: materials.php?msg=✅ Material added.'); exit;
  }
  if($a==='edit'){$id=(int)$_POST['mid'];
    mysqli_query($conn,"UPDATE materials SET material_name='$n',supplier='$s',price=$p WHERE material_id=$id");
    header('Location: materials.php?msg=✅ Updated.'); exit;
  }
}
if(isset($_GET['del'])){$id=(int)$_GET['del'];
  $c=mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) t FROM product_materials WHERE material_id=$id"));
  if($c['t']>0){header('Location: materials.php?msg=❌ In use by equipment — cannot delete.');exit;}
  mysqli_query($conn,"DELETE FROM materials WHERE material_id=$id");
  header('Location: materials.php?msg=🗑️ Deleted.'); exit;}
$mats=mysqli_query($conn,"SELECT * FROM materials ORDER BY material_name");
$edit=null;if(isset($_GET['edit']))$edit=mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM materials WHERE material_id=".(int)$_GET['edit']));
?>
<div class="page-header">
  <div class="page-title-block"><h1>📦 Raw Materials</h1><p>Manage raw materials, suppliers, and unit prices.</p></div>
</div>
<?php if($msg): ?><div class="alert alert-success"><?=e($msg)?></div><?php endif; ?>
<div class="card">
  <div class="card-head"><div class="card-head-icon"><?=$edit?'✏️':'➕'?></div>
    <div><div class="card-head-title"><?=$edit?'Edit: '.e($edit['material_name']):'Add New Material'?></div>
    <div class="card-head-sub">Include size/spec in name (e.g. "Steel Plate 4×8", "G.I. Pipe 1\"")</div></div>
  </div>
  <div class="card-body">
  <form method="post" enctype="multipart/form-data">
    <?=csrf_field()?>
    <input type="hidden" name="action" value="<?=$edit?'edit':'add'?>">
    <?php if($edit): ?><input type="hidden" name="mid" value="<?=$edit['material_id']?>"><?php endif; ?>
    <div class="field-grid">
      <div class="field"><label>Material Name *</label>
        <input type="text" name="material_name" required placeholder="e.g. Steel Plate 4×8, G.I. Pipe 1&quot;"
               value="<?=e($edit['material_name']??'')?>"></div>
      <div class="field"><label>Supplier *</label>
        <input type="text" name="supplier" required placeholder="e.g. CDO Steel Supply"
               value="<?=e($edit['supplier']??'')?>"></div>
      <div class="field"><label>Price per Unit (₱) *</label>
        <input type="number" step="0.01" name="price" required min="0" placeholder="0.00"
               value="<?=$edit['price']??''?>"></div>
      <div class="field"><label>Photo (optional)</label>
        <input type="file" name="img" accept="image/*"></div>
    </div>
    <div class="card-foot" style="padding:0;border:none;background:none;margin-top:8px;">
      <button type="submit" class="btn">💾 <?=$edit?'Update':'Save Material'?></button>
      <?php if($edit): ?><a href="materials.php" class="btn btn-ghost">Cancel</a><?php endif; ?>
    </div>
  </form>
  </div>
</div>

<h3 style="margin-bottom:12px;">📋 Materials List</h3>
<div class="table-wrap"><table><thead><tr><th>Photo</th><th>Material Name</th><th>Supplier</th><th>Price/unit</th><th>Added</th><th>Used In Equipment</th><th>Actions</th></tr></thead>
<tbody>
<?php while($m=mysqli_fetch_assoc($mats)):
  $usedR=mysqli_query($conn,"SELECT p.name FROM product_materials pm JOIN products p ON pm.product_id=p.id WHERE pm.material_id={$m['material_id']}");
  $used=[];while($u=mysqli_fetch_assoc($usedR))$used[]=e($u['name']);
?>
<tr>
  <td><?php if(!empty($m['image'])):?><img src="<?=e($m['image'])?>" style="width:46px;height:46px;object-fit:cover;border-radius:8px;border:1px solid var(--rim)"><?php else:?>📦<?php endif;?></td>
  <td><strong><?=e($m['material_name'])?></strong></td>
  <td style="color:var(--txt2)">🏭 <?=e($m['supplier'])?></td>
  <td class="mono" style="font-weight:700;color:var(--amber)">₱<?=number_format($m['price'],2)?></td>
  <td style="font-size:11.5px;color:var(--txt3)"><?=date('M j, Y',strtotime($m['created_at']))?></td>
  <td><?=$used?'<span style="font-size:12px;color:var(--txt2)">'.implode(', ',$used).'</span>':'<em style="color:var(--txt3);font-size:12px">Not yet used</em>'?></td>
  <td style="white-space:nowrap">
    <a href="?edit=<?=$m['material_id']?>" class="btn btn-ghost btn-xs">✏️</a>
    <a href="?del=<?=$m['material_id']?>" class="btn btn-danger btn-xs" onclick="return confirm('Delete?')">🗑️</a>
  </td>
</tr>
<?php endwhile; ?>
</tbody></table></div>
<?php require_once 'footer.php'; ?>
