<?php
require_once 'config.php';
function checkLogin():void { if(empty($_SESSION['user_id'])){header('Location: index.php');exit;} }
function checkAdmin():void { checkLogin(); if(($_SESSION['role']??'')!=='admin'){header('Location: staff_dashboard.php');exit;} }
function checkStaff():void { checkLogin(); if(($_SESSION['role']??'')!=='staff'){header('Location: dashboard.php');exit;} }
