<?php require_once 'header.php'; checkStaff();
mysqli_query($conn,"CREATE TABLE IF NOT EXISTS category_materials(id INT AUTO_INCREMENT PRIMARY KEY,category_id INT NOT NULL,material_id INT NOT NULL,default_qty INT DEFAULT 1,UNIQUE KEY uq(category_id,material_id))");
$msg=$_GET['msg']??'';

// ADD
if(isset($_POST['action'])&&$_POST['action']==='add'){csrf_verify();
  $n=esc($conn,$_POST['name']??''); $cid=(int)$_POST['category_id']; $stk=(int)$_POST['stock']; $lc=(float)$_POST['labor_cost'];
  $mc=0; $img='';
  if(isset($_FILES['img'])&&$_FILES['img']['error']===0){
    $ext=strtolower(pathinfo($_FILES['img']['name'],PATHINFO_EXTENSION));
    if(in_array($ext,['jpg','jpeg','png','gif','webp'])){$img='uploads/'.uniqid('eq_',true).'.'.$ext;move_uploaded_file($_FILES['img']['tmp_name'],$img);}
  }
  foreach($_POST['mats']??[] as $mid=>$d){if(!isset($d['use']))continue;
    $qty=max(1,(int)$d['qty']); $pr=mysqli_fetch_assoc(mysqli_query($conn,"SELECT price FROM materials WHERE material_id=".(int)$mid));
    if($pr)$mc+=$pr['price']*$qty;}
  $fp=($mc+$lc)*1.5;
  mysqli_query($conn,"INSERT INTO products(name,category_id,price,stock,labor_cost,material_cost,image)VALUES('$n',$cid,$fp,$stk,$lc,$mc,'$img')");
  $pid=mysqli_insert_id($conn);
  foreach($_POST['mats']??[] as $mid=>$d){if(!isset($d['use']))continue;
    $qty=max(1,(int)$d['qty']); mysqli_query($conn,"INSERT INTO product_materials(product_id,material_id,qty)VALUES($pid,".(int)$mid.",$qty)");}
  header('Location: products.php?msg=✅ Equipment added.'); exit;
}
// EDIT
if(isset($_POST['action'])&&$_POST['action']==='edit'){csrf_verify();
  $id=(int)$_POST['id']; $n=esc($conn,$_POST['name']??''); $cid=(int)$_POST['category_id']; $stk=(int)$_POST['stock']; $lc=(float)$_POST['labor_cost'];
  $mc=0; mysqli_query($conn,"DELETE FROM product_materials WHERE product_id=$id");
  foreach($_POST['mats']??[] as $mid=>$d){if(!isset($d['use']))continue;
    $qty=max(1,(int)$d['qty']); $pr=mysqli_fetch_assoc(mysqli_query($conn,"SELECT price FROM materials WHERE material_id=".(int)$mid));
    if($pr)$mc+=$pr['price']*$qty;
    mysqli_query($conn,"INSERT INTO product_materials(product_id,material_id,qty)VALUES($id,".(int)$mid.",$qty)");}
  $fp=($mc+$lc)*1.5;
  mysqli_query($conn,"UPDATE products SET name='$n',category_id=$cid,price=$fp,stock=$stk,labor_cost=$lc,material_cost=$mc WHERE id=$id");
  header('Location: products.php?msg=✅ Updated.'); exit;
}
if(isset($_GET['del'])){$id=(int)$_GET['del'];
  mysqli_query($conn,"DELETE FROM product_materials WHERE product_id=$id");
  mysqli_query($conn,"DELETE FROM products WHERE id=$id");
  header('Location: products.php?msg=🗑️ Deleted.'); exit;}

$cats=mysqli_query($conn,"SELECT * FROM categories ORDER BY category_name");
$matsQ=mysqli_query($conn,"SELECT * FROM materials ORDER BY material_name");
$allMats=[];while($m=mysqli_fetch_assoc($matsQ))$allMats[]=$m;
$prods=mysqli_query($conn,"SELECT p.*,c.category_name FROM products p LEFT JOIN categories c ON c.id=p.category_id ORDER BY p.id DESC");

// category→materials default map for JS
$cmapRes=mysqli_query($conn,"SELECT category_id,material_id,default_qty FROM category_materials");
$cmap=[];while($r=mysqli_fetch_assoc($cmapRes))$cmap[$r['category_id']][]=['id'=>(int)$r['material_id'],'qty'=>(int)$r['default_qty']];

$edit=null; $editMats=[];
if(isset($_GET['edit'])){$edit=mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM products WHERE id=".(int)$_GET['edit']));
  $r=mysqli_query($conn,"SELECT material_id,qty FROM product_materials WHERE product_id={$edit['id']}");
  while($x=mysqli_fetch_assoc($r))$editMats[$x['material_id']]=$x['qty'];}
?>
<div class="page-header">
  <div class="page-title-block"><h1>🔧 Equipment</h1>
    <p>Select category → materials auto-load. Quotation computed live.</p></div>
</div>
<?php if($msg): ?><div class="alert alert-success"><?=e($msg)?></div><?php endif; ?>

<div class="card">
  <div class="card-head"><div class="card-head-icon"><?=$edit?'✏️':'➕'?></div>
    <div><div class="card-head-title"><?=$edit?'Edit: '.e($edit['name']):'Add New Equipment'?></div>
    <div class="card-head-sub">Category → auto-loads materials · (Materials + Labor) × 1.5 = Final Price</div></div>
  </div>
  <div class="card-body">
  <form method="post" enctype="multipart/form-data">
    <?=csrf_field()?>
    <input type="hidden" name="action" value="<?=$edit?'edit':'add'?>">
    <?php if($edit): ?><input type="hidden" name="id" value="<?=$edit['id']?>"><?php endif; ?>
    <div class="field-grid">
      <div class="field"><label>Equipment Name *</label>
        <input type="text" name="name" required placeholder="e.g. Steel Gate 4×8ft" value="<?=e($edit['name']??'')?>"></div>
      <div class="field"><label>Equipment Type / Category *</label>
        <select name="category_id" id="catSel" required>
          <option value="">— Select Category —</option>
          <?php mysqli_data_seek($cats,0);while($c=mysqli_fetch_assoc($cats)):?>
          <option value="<?=$c['id']?>" <?=($edit&&$edit['category_id']==$c['id'])?'selected':''?>><?=e($c['category_name'])?></option>
          <?php endwhile;?>
        </select>
        <div class="field-hint">⚡ Selecting category auto-loads its default materials</div></div>
      <div class="field"><label>Stock Quantity *</label>
        <input type="number" name="stock" required min="0" placeholder="0" value="<?=$edit['stock']??''?>"></div>
      <div class="field"><label>Labor Cost (₱) *</label>
        <input type="number" step="0.01" name="labor_cost" id="laborCost" required min="0" placeholder="0.00" value="<?=$edit['labor_cost']??''?>"></div>
      <div class="field"><label>Equipment Photo</label>
        <input type="file" name="img" accept="image/*"></div>
    </div>

    <!-- Materials -->
    <div style="margin-top:16px;">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:10px;">
        <div style="font-size:12px;font-weight:700;color:var(--txt2);text-transform:uppercase;letter-spacing:.8px;">📦 Materials Used</div>
        <span id="autoMsg" class="badge b-amber" style="display:none">⚡ Auto-loaded from category</span>
      </div>
      <div id="nocat" style="background:var(--ink2);border:1px dashed var(--rim);border-radius:10px;padding:22px;text-align:center;color:var(--txt3);<?=$edit?'display:none':''?>">
        👆 Select Equipment Category above to auto-load materials
      </div>
      <div id="matWrap" style="<?=$edit?'':'display:none'?>">
        <div class="mat-grid-head"><div>Material / Supplier</div><div style="text-align:center">Qty</div><div style="text-align:right">Unit Price</div><div style="text-align:right">Subtotal</div></div>
        <div class="mat-row-wrap">
        <?php foreach($allMats as $m): $mid=$m['material_id']; $used=isset($editMats[$mid]); $qty=$used?$editMats[$mid]:1; ?>
        <div class="mat-row <?=$used?'mat-active':''?>" id="mr_<?=$mid?>" data-mid="<?=$mid?>" data-price="<?=$m['price']?>" style="<?=(!$edit)?'display:none':''?>">
          <label class="mat-check-label">
            <input type="checkbox" class="mat-cb" name="mats[<?=$mid?>][use]" data-mid="<?=$mid?>" <?=$used?'checked':''?> onchange="calc()">
            <div><div class="mat-name"><?=e($m['material_name'])?></div><div class="mat-supp">🏭 <?=e($m['supplier'])?></div></div>
          </label>
          <div style="text-align:center">
            <input type="number" class="qty-input mat-qty" name="mats[<?=$mid?>][qty]" value="<?=$qty?>" min="1" data-mid="<?=$mid?>" oninput="calc()">
          </div>
          <div class="mat-price">₱<?=number_format($m['price'],2)?></div>
          <div class="mat-sub <?=$used?'':'zero'?>" id="sub_<?=$mid?>"><?=$used?'₱'.number_format($m['price']*$qty,2):'—'?></div>
        </div>
        <?php endforeach; ?>
        </div>
      </div>
    </div>

    <!-- Live Quotation -->
    <div class="quot-box" id="quotBox" style="<?=$edit?'':'display:none'?>;margin-top:20px;">
      <div class="quot-head">📋 Full Price Quotation</div>
      <div class="quot-body">
        <div class="quot-line"><span class="ql">Materials Cost</span><span class="qv" id="qm">₱0.00</span></div>
        <div id="matBreakdown"></div>
        <div class="quot-line"><span class="ql">Labor Cost</span><span class="qv" id="ql">₱0.00</span></div>
        <div class="quot-line"><span class="ql">Base Cost (Materials + Labor)</span><span class="qv" id="qb">₱0.00</span></div>
        <div class="quot-line"><span class="ql">Markup (50%)</span><span class="qv" id="qmk">₱0.00</span></div>
      </div>
      <div class="quot-total"><span>💰 FINAL SELLING PRICE</span><span id="qf">₱0.00</span></div>
    </div>

    <div class="card-foot" style="padding:0;border:none;background:none;margin-top:20px;">
      <button type="submit" class="btn">💾 <?=$edit?'Update Equipment':'Save Equipment'?></button>
      <?php if($edit): ?><a href="products.php" class="btn btn-ghost">Cancel</a><?php endif; ?>
    </div>
  </form>
  </div>
</div>

<!-- Equipment List -->
<h3 style="margin-bottom:12px;">📋 Equipment List</h3>
<div class="table-wrap"><table><thead>
  <tr><th>Photo</th><th>Name</th><th>Category</th><th>Materials Used</th><th>Mat. Cost</th><th>Labor</th><th>Final Price</th><th>Stock</th><th>Actions</th></tr>
</thead><tbody>
<?php while($p=mysqli_fetch_assoc($prods)):
  $pmR=mysqli_query($conn,"SELECT m.material_name,pm.qty FROM product_materials pm JOIN materials m ON m.material_id=pm.material_id WHERE pm.product_id={$p['id']}");
  $ml=[];while($pm=mysqli_fetch_assoc($pmR))$ml[]='<span class="badge b-steel" style="margin:2px">'.e($pm['material_name']).' × '.$pm['qty'].'</span>';
?>
<tr>
  <td><?=!empty($p['image'])?'<img src="'.e($p['image']).'" style="width:48px;height:48px;object-fit:cover;border-radius:8px;border:1px solid var(--rim)">':'🔧'?></td>
  <td><strong style="font-family:\'Syne\',sans-serif"><?=e($p['name'])?></strong></td>
  <td><span class="badge b-muted"><?=e($p['category_name']??'—')?></span></td>
  <td><?=$ml?implode('',$ml):'<em style="color:var(--txt3);font-size:12px">None</em>'?></td>
  <td class="mono">₱<?=number_format($p['material_cost'],2)?></td>
  <td class="mono">₱<?=number_format($p['labor_cost'],2)?></td>
  <td class="mono" style="font-weight:700;color:var(--amber)">₱<?=number_format($p['price'],2)?></td>
  <td><?=$p['stock']<5?'<span class="badge b-rose">'.$p['stock'].' left</span>':'<span class="badge b-mint">'.$p['stock'].' units</span>'?></td>
  <td style="white-space:nowrap">
    <a href="?edit=<?=$p['id']?>" class="btn btn-ghost btn-xs">✏️</a>
    <a href="?del=<?=$p['id']?>" class="btn btn-danger btn-xs" onclick="return confirm('Delete equipment?')">🗑️</a>
  </td>
</tr>
<?php endwhile; ?>
</tbody></table></div>

<script>
const cmap=<?=json_encode($cmap)?>;
const fmt=v=>'₱'+parseFloat(v).toLocaleString('en-PH',{minimumFractionDigits:2,maximumFractionDigits:2});

document.getElementById('catSel').addEventListener('change',function(){
  const cid=parseInt(this.value);
  document.querySelectorAll('.mat-row').forEach(r=>{r.style.display='none';r.querySelector('.mat-cb').checked=false;r.querySelector('.mat-sub').textContent='—';r.querySelector('.mat-sub').className='mat-sub zero';});
  if(!cid){document.getElementById('nocat').style.display='block';document.getElementById('matWrap').style.display='none';document.getElementById('quotBox').style.display='none';document.getElementById('autoMsg').style.display='none';return;}
  const defs=cmap[cid]||[];
  if(defs.length){
    defs.forEach(d=>{const r=document.getElementById('mr_'+d.id);if(!r)return;r.style.display='';r.querySelector('.mat-cb').checked=true;r.querySelector('.mat-qty').value=d.qty;});
    document.getElementById('autoMsg').style.display='inline';
  } else {
    document.querySelectorAll('.mat-row').forEach(r=>r.style.display='');
    document.getElementById('autoMsg').style.display='none';
  }
  document.getElementById('nocat').style.display='none';
  document.getElementById('matWrap').style.display='block';
  calc();
});

function calc(){
  let mc=0; const brkd=[];
  document.querySelectorAll('.mat-row').forEach(row=>{
    if(row.style.display==='none')return;
    const cb=row.querySelector('.mat-cb'); const pr=parseFloat(row.dataset.price);
    const qty=parseInt(row.querySelector('.mat-qty').value)||1;
    const sub_el=row.querySelector('.mat-sub');
    const name=row.querySelector('.mat-name')?.textContent||'';
    if(cb&&cb.checked){const sub=pr*qty;mc+=sub;sub_el.textContent=fmt(sub);sub_el.className='mat-sub';brkd.push({name,qty,pr,sub});}
    else{sub_el.textContent='—';sub_el.className='mat-sub zero';}
  });
  const lc=parseFloat(document.getElementById('laborCost').value)||0;
  const base=mc+lc; const mk=base*.5; const fp=base*1.5;
  document.getElementById('qm').textContent=fmt(mc);
  document.getElementById('ql').textContent=fmt(lc);
  document.getElementById('qb').textContent=fmt(base);
  document.getElementById('qmk').textContent=fmt(mk);
  document.getElementById('qf').textContent=fmt(fp);
  document.getElementById('matBreakdown').innerHTML=brkd.map(b=>`<div class="quot-line indent"><span class="ql">${b.name} × ${b.qty} @ ${fmt(b.pr)}</span><span class="qv">${fmt(b.sub)}</span></div>`).join('');
  if(mc>0||lc>0) document.getElementById('quotBox').style.display='block';
}
document.getElementById('laborCost').addEventListener('input',calc);
<?php if($edit): ?>document.querySelectorAll('.mat-row').forEach(r=>r.style.display=''); document.getElementById('matWrap').style.display='block'; calc();<?php endif; ?>
</script>
<?php require_once 'footer.php'; ?>
