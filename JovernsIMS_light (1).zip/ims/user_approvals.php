<?php require_once 'header.php'; checkAdmin();
$msg=$_GET['msg']??'';
if(isset($_POST['action'])){csrf_verify();
  $a=$_POST['action']; $uid=(int)$_POST['uid'];
  if($a==='approve'){mysqli_query($conn,"UPDATE users SET approved=1 WHERE id=$uid"); header('Location: user_approvals.php?msg=✅ User approved.'); exit;}
  if($a==='reject'){mysqli_query($conn,"DELETE FROM users WHERE id=$uid AND approved=0"); header('Location: user_approvals.php?msg=🗑️ User rejected.'); exit;}
}
$pending=mysqli_query($conn,"SELECT * FROM users WHERE approved=0 ORDER BY id");
$approved=mysqli_query($conn,"SELECT * FROM users WHERE approved=1 ORDER BY role,username");
?>
<div class="page-header"><div class="page-title-block"><h1>✅ User Approvals</h1><p>Approve or reject new account requests.</p></div></div>
<?php if($msg): ?><div class="alert alert-success"><?=e($msg)?></div><?php endif; ?>

<h3 style="margin-bottom:12px;">⏳ Pending Approvals</h3>
<?php if(mysqli_num_rows($pending)===0): ?><div class="alert alert-info">No pending accounts.</div>
<?php else: ?>
<div class="table-wrap"><table><thead><tr><th>Name</th><th>Username</th><th>Age</th><th>Address</th><th>Role</th><th>Actions</th></tr></thead><tbody>
<?php while($u=mysqli_fetch_assoc($pending)): ?>
<tr>
  <td><strong><?=e($u['name']??'N/A')?></strong></td><td class="mono"><?=e($u['username'])?></td>
  <td><?=$u['age']??'—'?></td><td style="font-size:12px"><?=e($u['address']??'—')?></td>
  <td><span class="badge <?=$u['role']==='admin'?'b-amber':'b-mint'?>"><?=strtoupper(e($u['role']))?></span></td>
  <td style="white-space:nowrap">
    <form method="post" style="display:inline"><?=csrf_field()?><input type="hidden" name="uid" value="<?=$u['id']?>"><input type="hidden" name="action" value="approve"><button type="submit" class="btn btn-mint btn-xs">✅ Approve</button></form>
    <form method="post" style="display:inline"><?=csrf_field()?><input type="hidden" name="uid" value="<?=$u['id']?>"><input type="hidden" name="action" value="reject"><button type="submit" class="btn btn-danger btn-xs" onclick="return confirm('Reject this user?')">❌ Reject</button></form>
  </td>
</tr>
<?php endwhile; ?>
</tbody></table></div>
<?php endif; ?>

<h3 style="margin:24px 0 12px;">👥 All Approved Users</h3>
<div class="table-wrap"><table><thead><tr><th>Username</th><th>Name</th><th>Role</th><th>Address</th></tr></thead><tbody>
<?php while($u=mysqli_fetch_assoc($approved)): ?>
<tr>
  <td class="mono"><?=e($u['username'])?></td><td><?=e($u['name']??'—')?></td>
  <td><span class="badge <?=$u['role']==='admin'?'b-amber':'b-mint'?>"><?=strtoupper(e($u['role']))?></span></td>
  <td style="font-size:12px;color:var(--txt2)"><?=e($u['address']??'—')?></td>
</tr>
<?php endwhile; ?>
</tbody></table></div>
<?php require_once 'footer.php'; ?>
