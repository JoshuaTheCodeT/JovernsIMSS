<?php require_once 'header.php'; checkAdmin();
$sales=mysqli_query($conn,"SELECT s.*,p.name pname FROM sales s JOIN products p ON s.product_id=p.id ORDER BY s.date DESC,s.id DESC LIMIT 50");
$total=mysqli_fetch_assoc(mysqli_query($conn,"SELECT IFNULL(SUM(total_price),0) t FROM sales"))['t'];
?>
<div class="page-header"><div class="page-title-block"><h1>📈 Sales Reports</h1><p>Overview of all recorded sales.</p></div></div>
<div class="stat-grid" style="grid-template-columns:repeat(3,1fr)">
  <?php $cnt=mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) c FROM sales"))['c']; ?>
  <div class="stat-card c-amber"><span class="stat-icon">🧾</span><div class="stat-label">Total Transactions</div><div class="stat-val"><?=$cnt?></div></div>
  <div class="stat-card c-mint"><span class="stat-icon">💰</span><div class="stat-label">Total Revenue</div><div class="stat-val">₱<?=number_format($total,0)?></div></div>
  <div class="stat-card c-steel"><span class="stat-icon">📅</span><div class="stat-label">This Month</div>
    <?php $m=mysqli_fetch_assoc(mysqli_query($conn,"SELECT IFNULL(SUM(total_price),0) t FROM sales WHERE DATE_FORMAT(date,'%Y-%m')=DATE_FORMAT(CURDATE(),'%Y-%m')"))['t']; ?>
    <div class="stat-val">₱<?=number_format($m,0)?></div></div>
</div>
<div class="table-wrap"><table><thead><tr><th>#</th><th>Equipment</th><th>Qty</th><th>Total</th><th>Date</th></tr></thead><tbody>
<?php while($s=mysqli_fetch_assoc($sales)): ?>
<tr><td class="mono" style="color:var(--txt3)">#<?=$s['id']?></td><td><?=e($s['pname'])?></td><td><?=(int)$s['quantity']?></td>
  <td class="mono" style="font-weight:700;color:var(--amber)">₱<?=number_format($s['total_price'],2)?></td>
  <td style="font-size:12px;color:var(--txt3)"><?=date('M j, Y',strtotime($s['date']))?></td></tr>
<?php endwhile; ?>
</tbody></table></div>
<?php require_once 'footer.php'; ?>
