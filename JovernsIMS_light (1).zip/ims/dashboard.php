<?php require_once 'header.php'; checkAdmin();

// Stats
$daily  = mysqli_fetch_assoc(mysqli_query($conn,"SELECT IFNULL(SUM(total_price),0) a FROM sales WHERE date=CURDATE()"));
$month  = mysqli_fetch_assoc(mysqli_query($conn,"SELECT IFNULL(SUM(total_price),0) a FROM sales WHERE DATE_FORMAT(date,'%Y-%m')=DATE_FORMAT(CURDATE(),'%Y-%m')"));
$total  = mysqli_fetch_assoc(mysqli_query($conn,"SELECT IFNULL(SUM(total_price),0) a FROM sales"));
$clients= mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) a FROM customers"));
$orders = mysqli_fetch_assoc(mysqli_query($conn,"SELECT COUNT(*) a FROM purchases WHERE status NOT IN('Delivered')"));
$lowStk = mysqli_query($conn,"SELECT name,stock FROM products WHERE stock<5 ORDER BY stock");

$trendQ = mysqli_query($conn,"SELECT DATE(date) d,IFNULL(SUM(total_price),0) t FROM sales WHERE date>=DATE_SUB(CURDATE(),INTERVAL 30 DAY) GROUP BY DATE(date) ORDER BY d");
$tDates=[]; $tVals=[];
while($r=mysqli_fetch_assoc($trendQ)){$tDates[]=date('M d',strtotime($r['d']));$tVals[]=(float)$r['t'];}

$recentOrders = mysqli_query($conn,"SELECT pu.id,p.name pname,c.customer_name,pu.quantity,pu.cost,pu.status,pu.date FROM purchases pu JOIN products p ON pu.product_id=p.id LEFT JOIN customers c ON pu.customer_id=c.id ORDER BY pu.id DESC LIMIT 6");

// Staff create
$staffMsg='';
if(isset($_POST['create_staff'])){csrf_verify();
  $su=trim($_POST['su']??'');$sp=trim($_POST['sp']??'');
  if($su&&$sp){
    $chk=$conn->prepare("SELECT id FROM users WHERE username=? LIMIT 1");
    $chk->bind_param('s',$su);$chk->execute();$chk->store_result();
    if($chk->num_rows>0){$staffMsg='error:Username taken.';}
    else{$h=password_hash($sp,PASSWORD_BCRYPT);
      $ins=$conn->prepare("INSERT INTO users(username,password,role,approved)VALUES(?,?,'staff',1)");
      $ins->bind_param('ss',$su,$h);$staffMsg=$ins->execute()?'success:Staff account created!':'error:Error.';}
  }else $staffMsg='error:Fill all fields.';
}
[$sm,$st]=explode(':',$staffMsg??':',2)+['',''];
?>

<div class="stat-grid">
  <div class="stat-card c-amber">
    <span class="stat-icon">📅</span>
    <div class="stat-label">Daily Sales</div>
    <div class="stat-val">₱<?=number_format($daily['a'],0)?></div>
    <div class="stat-hint"><?=date('F j, Y')?></div>
  </div>
  <div class="stat-card c-steel">
    <span class="stat-icon">📆</span>
    <div class="stat-label">Monthly Sales</div>
    <div class="stat-val">₱<?=number_format($month['a'],0)?></div>
    <div class="stat-hint"><?=date('F Y')?></div>
  </div>
  <div class="stat-card c-mint">
    <span class="stat-icon">💰</span>
    <div class="stat-label">Total Revenue</div>
    <div class="stat-val">₱<?=number_format($total['a'],0)?></div>
    <div class="stat-hint">All time</div>
  </div>
  <div class="stat-card c-gold">
    <span class="stat-icon">👥</span>
    <div class="stat-label">Total Clients</div>
    <div class="stat-val"><?=(int)$clients['a']?></div>
    <div class="stat-hint"><?=(int)$orders['a']?> active orders</div>
  </div>
</div>

<?php if(mysqli_num_rows($lowStk)>0): ?>
<div class="alert alert-error" style="margin-bottom:16px;">
  ⚠️ <strong>Low Stock Alert:</strong>
  <?php $ls=[];while($r=mysqli_fetch_assoc($lowStk))$ls[]=e($r['name']).' ('.$r['stock'].')'; echo implode(', ',$ls);?>
</div>
<?php endif; ?>

<div style="display:grid;grid-template-columns:2fr 1fr;gap:20px;margin-bottom:24px;">
  <!-- Sales Chart -->
  <div class="chart-wrap">
    <h3 style="margin-bottom:16px;">📈 Sales Trend — Last 30 Days</h3>
    <div style="position:relative;height:260px;">
      <canvas id="trendChart"></canvas>
    </div>
  </div>
  <!-- Create Staff -->
  <div class="card" style="margin-bottom:0;">
    <div class="card-head"><div class="card-head-icon">👤</div><div><div class="card-head-title">Create Staff</div><div class="card-head-sub">Add new staff account</div></div></div>
    <div class="card-body">
      <?php if($st): ?><div class="alert alert-<?=$sm==='success'?'success':'error'?>"><?=e($st)?></div><?php endif; ?>
      <form method="post">
        <?=csrf_field()?>
        <div class="field" style="margin-bottom:12px;"><label>Username</label><input type="text" name="su" required placeholder="e.g. staff01"></div>
        <div class="field" style="margin-bottom:12px;"><label>Password</label><input type="password" name="sp" required placeholder="Min. 6 chars"></div>
        <button type="submit" name="create_staff" class="btn btn-steel w-full" style="justify-content:center;">➕ Create Staff</button>
      </form>
    </div>
  </div>
</div>

<!-- Recent Orders -->
<div class="card">
  <div class="card-head"><div class="card-head-icon">🛒</div><div><div class="card-head-title">Recent Equipment Orders</div><div class="card-head-sub">Latest 6 orders</div></div></div>
  <div class="table-wrap" style="border:none;border-radius:0;box-shadow:none;">
    <table><thead><tr><th>#</th><th>Client</th><th>Equipment</th><th>Qty</th><th>Total</th><th>Date</th><th>Status</th></tr></thead>
    <tbody>
    <?php while($r=mysqli_fetch_assoc($recentOrders)):
      $sc=['Pending'=>'b-amber','Fabricating'=>'b-steel','Quality Check'=>'b-steel','Delivered'=>'b-mint','Repair'=>'b-rose'][$r['status']]??'b-muted';
    ?>
    <tr>
      <td class="mono" style="color:var(--txt3)">#<?=$r['id']?></td>
      <td><?=$r['customer_name']?e($r['customer_name']):'<em style="color:var(--txt3)">Walk-in</em>'?></td>
      <td><?=e($r['pname'])?></td>
      <td><?=(int)$r['quantity']?></td>
      <td class="mono" style="font-weight:700;color:var(--amber)">₱<?=number_format($r['cost'],2)?></td>
      <td style="color:var(--txt3);font-size:12px"><?=date('M j',strtotime($r['date']))?></td>
      <td><span class="badge <?=$sc?>"><?=e($r['status'])?></span></td>
    </tr>
    <?php endwhile; ?>
    </tbody></table>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script>
new Chart(document.getElementById('trendChart'),{
  type:'line',
  data:{labels:<?=json_encode($tDates)?>,datasets:[{
    label:'Daily Sales (₱)',
    data:<?=json_encode($tVals)?>,
    borderColor:'#f0a500',backgroundColor:'rgba(240,165,0,.08)',
    borderWidth:2.5,fill:true,tension:.4,
    pointRadius:4,pointBackgroundColor:'#f0a500',pointBorderColor:'#0a0c10',pointBorderWidth:2
  }]},
  options:{responsive:true,maintainAspectRatio:false,
    plugins:{legend:{display:false},tooltip:{callbacks:{label:c=>'₱'+c.parsed.y.toLocaleString('en-PH',{minimumFractionDigits:2})}}},
    scales:{
      y:{beginAtZero:true,grid:{color:'rgba(46,58,82,.4)'},ticks:{color:'#7a8faa',callback:v=>'₱'+v.toLocaleString()}},
      x:{grid:{display:false},ticks:{color:'#7a8faa',font:{size:11}}}
    }
  }
});
</script>
<?php require_once 'footer.php'; ?>
