<?php require_once 'header.php'; checkAdmin();
$delivered=mysqli_query($conn,"SELECT pu.*,p.name pname,c.customer_name FROM purchases pu JOIN products p ON pu.product_id=p.id LEFT JOIN customers c ON pu.customer_id=c.id WHERE pu.status='Delivered' ORDER BY pu.id DESC");
?>
<div class="page-header"><div class="page-title-block"><h1>🗃️ Archives</h1><p>Completed / delivered orders archive.</p></div></div>
<div class="table-wrap"><table><thead><tr><th>#</th><th>Client</th><th>Equipment</th><th>Qty</th><th>Total</th><th>Date</th><th>Status</th></tr></thead><tbody>
<?php while($r=mysqli_fetch_assoc($delivered)): ?>
<tr><td class="mono" style="color:var(--txt3)">#<?=$r['id']?></td>
  <td><?=$r['customer_name']?e($r['customer_name']):'<em style="color:var(--txt3)">Walk-in</em>'?></td>
  <td><?=e($r['pname'])?></td><td><?=(int)$r['quantity']?></td>
  <td class="mono" style="font-weight:700;color:var(--mint)">₱<?=number_format($r['cost'],2)?></td>
  <td style="font-size:12px;color:var(--txt3)"><?=date('M j, Y',strtotime($r['date']))?></td>
  <td><span class="badge b-mint">Delivered</span></td>
</tr>
<?php endwhile; ?>
</tbody></table></div>
<?php require_once 'footer.php'; ?>
