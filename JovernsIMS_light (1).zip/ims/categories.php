<?php require_once 'header.php'; checkAdmin();
mysqli_query($conn,"CREATE TABLE IF NOT EXISTS category_materials(id INT AUTO_INCREMENT PRIMARY KEY,category_id INT NOT NULL,material_id INT NOT NULL,default_qty INT DEFAULT 1,UNIQUE KEY uq(category_id,material_id))");
$msg=$_GET['msg']??'';

if($_SERVER['REQUEST_METHOD']==='POST'){
  csrf_verify(); $a=$_POST['action']??''; $n=esc($conn,$_POST['category_name']??'');
  if($a==='add'&&$n){
    mysqli_query($conn,"INSERT INTO categories(category_name)VALUES('$n')");
    $cid=mysqli_insert_id($conn);
    foreach($_POST['mats']??[] as $mid=>$d){if(!isset($d['use']))continue;
      $mid=(int)$mid;$qty=max(1,(int)($d['qty']??1));
      mysqli_query($conn,"INSERT IGNORE INTO category_materials(category_id,material_id,default_qty)VALUES($cid,$mid,$qty)");}
    header('Location: categories.php?msg=✅ Category added.'); exit;
  }
  if($a==='edit'){$id=(int)$_POST['id'];
    mysqli_query($conn,"UPDATE categories SET category_name='$n' WHERE id=$id");
    mysqli_query($conn,"DELETE FROM category_materials WHERE category_id=$id");
    foreach($_POST['mats']??[] as $mid=>$d){if(!isset($d['use']))continue;
      $mid=(int)$mid;$qty=max(1,(int)($d['qty']??1));
      mysqli_query($conn,"INSERT IGNORE INTO category_materials(category_id,material_id,default_qty)VALUES($id,$mid,$qty)");}
    header('Location: categories.php?msg=✅ Category updated.'); exit;
  }
}
if(isset($_GET['delete'])){$id=(int)$_GET['delete'];
  mysqli_query($conn,"DELETE FROM category_materials WHERE category_id=$id");
  mysqli_query($conn,"DELETE FROM categories WHERE id=$id");
  header('Location: categories.php?msg=🗑️ Deleted.'); exit;}

$cats=mysqli_query($conn,"SELECT * FROM categories ORDER BY category_name");
$mats=mysqli_query($conn,"SELECT * FROM materials ORDER BY material_name");
$matList=[];while($m=mysqli_fetch_assoc($mats))$matList[]=$m;
$edit=null; $editMats=[];
if(isset($_GET['edit'])){$edit=mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM categories WHERE id=".(int)$_GET['edit']));
  $r=mysqli_query($conn,"SELECT * FROM category_materials WHERE category_id={$edit['id']}");
  while($x=mysqli_fetch_assoc($r))$editMats[$x['material_id']]=$x['default_qty'];}
?>
<div class="page-header">
  <div class="page-title-block"><h1>🗂️ Equipment Categories</h1>
    <p>Assign default materials per category — auto-loads when adding equipment.</p></div>
</div>
<?php if($msg): ?><div class="alert alert-success"><?=e($msg)?></div><?php endif; ?>
<div class="card">
  <div class="card-head"><div class="card-head-icon"><?=$edit?'✏️':'➕'?></div>
    <div><div class="card-head-title"><?=$edit?'Edit: '.e($edit['category_name']):'Add New Category'?></div>
    <div class="card-head-sub">Set default materials &amp; quantities — will auto-load in Equipment form</div></div>
  </div>
  <div class="card-body">
  <form method="post">
    <?=csrf_field()?>
    <input type="hidden" name="action" value="<?=$edit?'edit':'add'?>">
    <?php if($edit): ?><input type="hidden" name="id" value="<?=$edit['id']?>"><?php endif; ?>
    <div class="field" style="margin-bottom:18px;">
      <label>Category / Equipment Type Name *</label>
      <input type="text" name="category_name" required placeholder="e.g. Steel Gates, Water Tanks, Trailers…"
             value="<?=e($edit['category_name']??'')?>">
    </div>
    <?php if(!empty($matList)): ?>
    <div style="margin-bottom:4px;font-size:12px;font-weight:700;color:var(--txt2);text-transform:uppercase;letter-spacing:.8px;">
      📦 Default Materials &amp; Quantities
      <span style="font-weight:400;color:var(--txt3);font-size:11px;margin-left:6px;">— Auto-loaded when this category is selected in Equipment form</span>
    </div>
    <div class="mat-grid-head"><div>Material / Supplier</div><div style="text-align:center">Default Qty</div><div style="text-align:right">Unit Price</div><div style="text-align:right">Include?</div></div>
    <div class="mat-row-wrap">
    <?php foreach($matList as $m): $mid=$m['material_id']; $ch=isset($editMats[$mid]); $dq=$ch?$editMats[$mid]:1; ?>
    <div class="mat-row <?=$ch?'mat-active':''?>">
      <div><div class="mat-name"><?=e($m['material_name'])?></div><div class="mat-supp">🏭 <?=e($m['supplier'])?></div></div>
      <div style="text-align:center"><input type="number" class="qty-input" name="mats[<?=$mid?>][qty]" value="<?=$dq?>" min="1"></div>
      <div class="mat-price">₱<?=number_format($m['price'],2)?></div>
      <div style="text-align:right">
        <label style="display:inline-flex;align-items:center;gap:6px;cursor:pointer;margin:0;font-size:13px;font-weight:600;color:var(--txt);">
          <input type="checkbox" name="mats[<?=$mid?>][use]" <?=$ch?'checked':''?>> Use
        </label>
      </div>
    </div>
    <?php endforeach; ?>
    </div>
    <?php else: ?><div class="alert alert-info">ℹ️ Add materials first on the <a href="materials.php">Materials page</a>.</div><?php endif; ?>
    <div class="card-foot" style="margin-top:20px;padding:0;border:none;background:none;">
      <button type="submit" class="btn">💾 <?=$edit?'Update':'Save Category'?></button>
      <?php if($edit): ?><a href="categories.php" class="btn btn-ghost">Cancel</a><?php endif; ?>
    </div>
  </form>
  </div>
</div>

<h3 style="margin-bottom:12px;">📋 Category List</h3>
<div class="table-wrap"><table><thead><tr><th>Category</th><th>Default Materials (auto-loaded)</th><th>Actions</th></tr></thead><tbody>
<?php mysqli_data_seek($cats,0); while($c=mysqli_fetch_assoc($cats)):
  $cmR=mysqli_query($conn,"SELECT m.material_name,cm.default_qty FROM category_materials cm JOIN materials m ON m.material_id=cm.material_id WHERE cm.category_id={$c['id']} ORDER BY m.material_name");
  $cms=[];while($x=mysqli_fetch_assoc($cmR))$cms[]=$x;
?>
<tr>
  <td><strong style="font-family:'Syne',sans-serif"><?=e($c['category_name'])?></strong></td>
  <td><?php if($cms){foreach($cms as $x)echo '<span class="badge b-amber" style="margin:2px">'.e($x['material_name']).' × '.$x['default_qty'].'</span> ';}else echo '<em style="color:var(--txt3);font-size:12px">No defaults set</em>'; ?></td>
  <td style="white-space:nowrap">
    <a href="?edit=<?=$c['id']?>" class="btn btn-ghost btn-xs">✏️ Edit</a>
    <a href="?delete=<?=$c['id']?>" class="btn btn-danger btn-xs" onclick="return confirm('Delete?')">🗑️</a>
  </td>
</tr>
<?php endwhile; ?>
</tbody></table></div>
<?php require_once 'footer.php'; ?>
