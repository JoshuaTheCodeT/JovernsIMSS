-- ================================================================
--  Jovern's Fabricating Shop — IMS  |  FAB-IT2-02
--  FINAL DATABASE  |  Run this in phpMyAdmin
-- ================================================================
CREATE DATABASE IF NOT EXISTS inventory_db;
USE inventory_db;
SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS `categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `customers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_name` varchar(100) NOT NULL,
  `contact` varchar(100),
  `email` varchar(255),
  `address` varchar(255),
  `client_type` varchar(50) DEFAULT 'Walk-in',
  `payment_terms` varchar(50) DEFAULT 'COD',
  `created_at` date NOT NULL DEFAULT (curdate()),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `materials` (
  `material_id` int(11) NOT NULL AUTO_INCREMENT,
  `material_name` varchar(150) NOT NULL,
  `supplier` varchar(150) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `image` varchar(255),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`material_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `category_materials` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) NOT NULL,
  `material_id` int(11) NOT NULL,
  `default_qty` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_cat_mat` (`category_id`,`material_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `products` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `category_id` int(11),
  `price` decimal(10,2) NOT NULL,
  `original_price` decimal(10,2),
  `stock` int(11) NOT NULL DEFAULT 0,
  `labor_cost` decimal(10,2) DEFAULT 0.00,
  `material_cost` decimal(10,2) DEFAULT 0.00,
  `image` varchar(255),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `product_materials` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `material_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_prod_mat` (`product_id`,`material_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `sales` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `date` date NOT NULL,
  `purchase_id` int(11),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sale_id` int(11) NOT NULL,
  `payment_method` varchar(50) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `purchases` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `customer_id` int(11),
  `quantity` int(11) NOT NULL,
  `cost` decimal(10,2) NOT NULL,
  `original_cost` decimal(10,2),
  `discount` decimal(10,2) DEFAULT 0.00,
  `date` date NOT NULL,
  `status` enum('Pending','Fabricating','Quality Check','Delivered','Repair') DEFAULT 'Pending',
  `notes` text,
  `created_by` varchar(30),
  `completed_date` date,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `stock_logs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_id` int(11) NOT NULL,
  `change_type` varchar(20) NOT NULL,
  `quantity` int(11) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50),
  `password` varchar(255),
  `name` varchar(100),
  `age` int(3),
  `address` varchar(255),
  `role` varchar(20),
  `approved` tinyint(1) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ⚠️ Default accounts — plain text passwords stored temporarily
-- The system will auto-upgrade to bcrypt on first login
INSERT IGNORE INTO `users` (`id`,`username`,`password`,`name`,`role`,`approved`) VALUES
(1, 'admin', 'admin123', 'Administrator', 'admin', 1),
(2, 'staff', 'staff123', 'Staff User',    'staff', 1);
