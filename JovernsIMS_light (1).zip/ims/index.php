<?php
require_once 'config.php';
require_once 'db.php';

// Already logged in
if (!empty($_SESSION['user_id'])) {
    header('Location: ' . ($_SESSION['role']==='admin' ? 'dashboard.php' : 'staff_dashboard.php'));
    exit;
}

$error = $regMsg = '';
$showTab = 'login';

// ── LOGIN ──────────────────────────────────────────────────
if (isset($_POST['login'])) {
    csrf_verify();
    $u = trim($_POST['username'] ?? '');
    $p = trim($_POST['password'] ?? '');

    $st = $conn->prepare("SELECT id, username, password, role, approved FROM users WHERE username = ? LIMIT 1");
    $st->bind_param('s', $u);
    $st->execute();
    $row = $st->get_result()->fetch_assoc();
    $st->close();

    if ($row) {
        // Check password: try bcrypt first, then plain text (legacy)
        $pwOk = false;
        if (password_verify($p, $row['password'])) {
            $pwOk = true; // already hashed
        } elseif ($p === $row['password']) {
            $pwOk = true;
            // ✅ AUTO-UPGRADE: plain text → bcrypt on first login
            $newHash = password_hash($p, PASSWORD_BCRYPT);
            $conn->prepare("UPDATE users SET password=? WHERE id=?")->execute() ?: null;
            $upd = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
            $upd->bind_param('si', $newHash, $row['id']);
            $upd->execute();
            $upd->close();
        }

        if ($pwOk) {
            if (!$row['approved']) {
                $error = 'Your account is pending admin approval.';
            } else {
                session_regenerate_id(true);
                $_SESSION['user_id']  = $row['id'];
                $_SESSION['username'] = $row['username'];
                $_SESSION['role']     = $row['role'];
                header('Location: ' . ($row['role'] === 'admin' ? 'dashboard.php' : 'staff_dashboard.php'));
                exit;
            }
        } else {
            $error = 'Wrong password. Please try again.';
        }
    } else {
        $error = 'Username not found.';
    }
}

// ── REGISTER ──────────────────────────────────────────────
if (isset($_POST['register'])) {
    csrf_verify();
    $showTab = 'register';

    $un = trim($_POST['reg_username'] ?? '');
    $pw = trim($_POST['reg_password'] ?? '');
    $nm = trim($_POST['reg_name']     ?? '');
    $ag = intval($_POST['reg_age']    ?? 0);
    $ad = trim($_POST['reg_address']  ?? '');
    $ro = in_array($_POST['reg_role'] ?? '', ['staff','admin']) ? $_POST['reg_role'] : 'staff';

    if (!$un || !$pw || !$nm || !$ag || !$ad) {
        $regMsg = 'error:Please fill in all fields.';
    } elseif (strlen($pw) < 6) {
        $regMsg = 'error:Password must be at least 6 characters.';
    } else {
        $chk = $conn->prepare("SELECT id FROM users WHERE username = ? LIMIT 1");
        $chk->bind_param('s', $un);
        $chk->execute();
        $chk->store_result();

        if ($chk->num_rows > 0) {
            $regMsg = 'error:Username already taken. Choose another.';
        } else {
            // ✅ Store as REAL bcrypt hash — this is the actual password
            $hashed = password_hash($pw, PASSWORD_BCRYPT);

            $ins = $conn->prepare(
                "INSERT INTO users (username, password, name, age, address, role, approved) VALUES (?, ?, ?, ?, ?, ?, 0)"
            );
            $ins->bind_param('sssiss', $un, $hashed, $nm, $ag, $ad, $ro);

            if ($ins->execute()) {
                $regMsg  = 'success:Account created successfully! Please wait for admin approval before logging in.';
                $showTab = 'login';
            } else {
                $regMsg = 'error:Something went wrong. Please try again.';
            }
            $ins->close();
        }
        $chk->close();
    }
}

[$rType, $rText] = $regMsg ? explode(':', $regMsg, 2) : ['', ''];
?>
<!DOCTYPE html>
<html lang="fil">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="X-Frame-Options" content="DENY">
<title>Login — Jovern's Fabricating Shop IMS</title>
<link rel="stylesheet" href="styles.css">
</head>
<body class="login-page">

<div class="login-wrap">
  <div class="login-box">

    <!-- Hero -->
    <div class="login-hero">
      <span class="login-gear">⚙️</span>
      <div class="login-shop">Jovern's Fabricating Shop</div>
      <div class="login-sys">Inventory &amp; Monitoring System · FAB-IT2-02</div>
    </div>

    <!-- Body -->
    <div class="login-body-section">

      <!-- Alerts -->
      <?php if ($error): ?>
        <div class="alert alert-error" style="margin-bottom:14px;">⚠️ <?= e($error) ?></div>
      <?php endif; ?>
      <?php if ($rText && $rType === 'success'): ?>
        <div class="alert alert-success" style="margin-bottom:14px;">✅ <?= e($rText) ?></div>
      <?php elseif ($rText && $rType === 'error'): ?>
        <div class="alert alert-error" style="margin-bottom:14px;">⚠️ <?= e($rText) ?></div>
      <?php endif; ?>

      <!-- Tabs -->
      <div class="tab-btns">
        <button class="tab-btn <?= $showTab==='login' ? 'active' : '' ?>" onclick="switchTab('login')">🔐 Login</button>
        <button class="tab-btn <?= $showTab==='register' ? 'active' : '' ?>" onclick="switchTab('register')">📝 Sign Up</button>
      </div>

      <!-- LOGIN TAB -->
      <div id="tab-login" <?= $showTab !== 'login' ? 'style="display:none"' : '' ?>>
        <form method="post" autocomplete="off">
          <?= csrf_field() ?>
          <div class="form-group">
            <label>Username</label>
            <input type="text" name="username" placeholder="Enter your username" required autofocus>
          </div>
          <div class="form-group">
            <label>Password</label>
            <input type="password" name="password" placeholder="Enter your password" required>
          </div>
          <button type="submit" name="login" class="btn" style="width:100%;justify-content:center;margin-top:6px;">
            🔐 Sign In
          </button>
        </form>
        <p style="text-align:center;margin-top:14px;font-size:12.5px;color:var(--txt3);">
          Default accounts: <strong style="color:var(--txt2)">admin / admin123</strong> &nbsp;·&nbsp; <strong style="color:var(--txt2)">staff / staff123</strong>
        </p>
      </div>

      <!-- REGISTER TAB -->
      <div id="tab-register" <?= $showTab !== 'register' ? 'style="display:none"' : '' ?>>
        <form method="post" autocomplete="off">
          <?= csrf_field() ?>
          <div class="form-group">
            <label>Full Name *</label>
            <input type="text" name="reg_name" placeholder="e.g. Juan Dela Cruz" required>
          </div>
          <div style="display:grid;grid-template-columns:1fr 1fr;gap:12px;">
            <div class="form-group">
              <label>Age *</label>
              <input type="number" name="reg_age" min="16" max="80" placeholder="20" required>
            </div>
            <div class="form-group">
              <label>Role *</label>
              <select name="reg_role">
                <option value="staff">Staff</option>
                <option value="admin">Admin</option>
              </select>
            </div>
          </div>
          <div class="form-group">
            <label>Address *</label>
            <input type="text" name="reg_address" placeholder="City, Province" required>
          </div>
          <div class="form-group">
            <label>Username *</label>
            <input type="text" name="reg_username" placeholder="Choose a username" required>
          </div>
          <div class="form-group">
            <label>Password * <span style="font-weight:400;color:var(--txt3)">(min. 6 characters)</span></label>
            <input type="password" name="reg_password" placeholder="Enter your real password" minlength="6" required>
          </div>
          <button type="submit" name="register" class="btn btn-mint" style="width:100%;justify-content:center;margin-top:6px;">
            📝 Create Account
          </button>
          <p style="text-align:center;margin-top:10px;font-size:12px;color:var(--txt3);">
            Account needs admin approval before you can login.
          </p>
        </form>
      </div>

    </div>

    <div class="login-footer-note">
      © <?= date('Y') ?> Jovern's Fabricating Shop &nbsp;·&nbsp;
      Salvatiera · Aberde · Embornas · Toledo · Gonzaga
    </div>
  </div>
</div>

<script>
function switchTab(t) {
  document.getElementById('tab-login').style.display    = t === 'login'    ? 'block' : 'none';
  document.getElementById('tab-register').style.display = t === 'register' ? 'block' : 'none';
  document.querySelectorAll('.tab-btn').forEach((b, i) => {
    b.classList.toggle('active', (i===0 && t==='login') || (i===1 && t==='register'));
  });
}
</script>
</body>
</html>
