<?php require_once 'header.php'; checkStaff();
$prods=mysqli_query($conn,"SELECT COUNT(*) a FROM products WHERE stock>0");$pc=mysqli_fetch_assoc($prods)['a'];
$myOrds=mysqli_query($conn,"SELECT COUNT(*) a FROM purchases WHERE status NOT IN('Delivered')");$oc=mysqli_fetch_assoc($myOrds)['a'];
$recent=mysqli_query($conn,"SELECT pu.*,p.name pname,c.customer_name FROM purchases pu JOIN products p ON pu.product_id=p.id LEFT JOIN customers c ON pu.customer_id=c.id ORDER BY pu.id DESC LIMIT 8");
?>
<div class="purpose-banner"><div class="pb-icon">🏭</div><div>
  <div class="pb-title">Staff Panel — Jovern's Fabricating Shop IMS</div>
  <div class="pb-body">View equipment, manage client orders, and track fabrication status. Contact admin for material/equipment changes.</div>
</div></div>
<div class="stat-grid">
  <div class="stat-card c-amber"><span class="stat-icon">🔧</span><div class="stat-label">In-Stock Equipment</div><div class="stat-val"><?=$pc?></div><div class="stat-hint">Types available</div></div>
  <div class="stat-card c-steel"><span class="stat-icon">🛒</span><div class="stat-label">Active Orders</div><div class="stat-val"><?=$oc?></div><div class="stat-hint">Pending / Fabricating</div></div>
</div>
<h3 style="margin-bottom:12px;">📋 Recent Orders</h3>
<div class="table-wrap"><table><thead><tr><th>#</th><th>Client</th><th>Equipment</th><th>Qty</th><th>Total</th><th>Date</th><th>Status</th></tr></thead><tbody>
<?php while($r=mysqli_fetch_assoc($recent)):$sc=['Pending'=>'b-amber','Fabricating'=>'b-steel','Quality Check'=>'b-steel','Delivered'=>'b-mint','Repair'=>'b-rose'][$r['status']]??'b-muted';?>
<tr><td class="mono" style="color:var(--txt3)">#<?=$r['id']?></td>
  <td><?=$r['customer_name']?e($r['customer_name']):'<em style="color:var(--txt3)">Walk-in</em>'?></td>
  <td><?=e($r['pname'])?></td><td><?=(int)$r['quantity']?></td>
  <td class="mono" style="font-weight:700;color:var(--amber)">₱<?=number_format($r['cost'],2)?></td>
  <td style="font-size:12px;color:var(--txt3)"><?=date('M j',strtotime($r['date']))?></td>
  <td><span class="badge <?=$sc?>"><?=e($r['status'])?></span></td>
</tr>
<?php endwhile; ?>
</tbody></table></div>
<?php require_once 'footer.php'; ?>
