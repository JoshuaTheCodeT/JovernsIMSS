<?php
require_once 'config.php';
require_once 'db.php';
require_once 'auth.php';
checkLogin();
$cur  = basename($_SERVER['PHP_SELF']);
$role = $_SESSION['role']??'staff';
$uname= $_SESSION['username']??'User';
function nl(string $href,string $icon,string $label,string $cur,string $forRole='both'):void{
    global $role;
    if($forRole==='admin'&&$role!=='admin') return;
    if($forRole==='staff'&&$role!=='staff') return;
    $a=$cur===$href?' active':'';
    echo "<a href=\"$href\" class=\"nav-link$a\"><span class=\"ni\">$icon</span><span>$label</span></a>\n";
}
// Build page title from filename
$titles=['dashboard.php'=>['📊','Dashboard'],'staff_dashboard.php'=>['📊','Dashboard'],
 'categories.php'=>['🗂️','Equipment Categories'],'materials.php'=>['📦','Raw Materials'],
 'products.php'=>['🔧','Equipment'],'staff_products.php'=>['🔧','Equipment'],
 'customers.php'=>['👥','Clients'],'staff_customer.php'=>['👥','Clients'],
 'purchases.php'=>['🛒','Equipment Orders'],'staff_purchases.php'=>['🛒','Equipment Orders'],
 'reports.php'=>['📈','Sales Reports'],'archives.php'=>['🗃️','Archives'],
 'user_approvals.php'=>['✅','User Approvals'],'materials.php'=>['📦','Raw Materials']];
[$pIcon,$pTitle]=$titles[$cur]??['📄',ucfirst(str_replace(['.php','_'],' ',$cur))];
?>
<!DOCTYPE html><html lang="fil"><head>
<meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta http-equiv="X-Frame-Options" content="DENY">
<meta http-equiv="X-Content-Type-Options" content="nosniff">
<title><?=e($pTitle)?> — Jovern's IMS</title>
<link rel="stylesheet" href="styles.css">
</head><body>
<div class="layout">
<aside class="sidebar">
  <div class="brand">
    <div class="brand-mark">
      <div class="brand-icon">⚙️</div>
      <div>
        <div class="brand-name">Jovern's Fabricating</div>
        <div class="brand-sub">Inventory &amp; Monitoring System</div>
      </div>
    </div>
  </div>
  <div class="nav-body">
    <div class="nav-label">Overview</div>
    <?php nl('dashboard.php','📊','Dashboard',$cur,'admin'); ?>
    <?php nl('staff_dashboard.php','📊','Dashboard',$cur,'staff'); ?>

    <div class="nav-label">Inventory</div>
    <?php nl('categories.php','🗂️','Equipment Categories',$cur,'admin'); ?>
    <?php nl('materials.php','📦','Raw Materials',$cur,'admin'); ?>
    <?php nl('products.php','🔧','Equipment',$cur,'admin'); ?>
    <?php nl('staff_products.php','🔧','Equipment',$cur,'staff'); ?>

    <div class="nav-label">Orders &amp; Clients</div>
    <?php nl('customers.php','👥','Clients',$cur,'admin'); ?>
    <?php nl('staff_customer.php','👥','Clients',$cur,'staff'); ?>
    <?php nl('purchases.php','🛒','Equipment Orders',$cur,'admin'); ?>
    <?php nl('staff_purchases.php','🛒','Equipment Orders',$cur,'staff'); ?>

    <div class="nav-label">Reports</div>
    <?php nl('reports.php','📈','Sales Reports',$cur,'admin'); ?>
    <?php nl('archives.php','🗃️','Archives',$cur,'admin'); ?>

    <?php if($role==='admin'): ?>
    <div class="nav-label">Admin</div>
    <?php nl('user_approvals.php','✅','User Approvals',$cur,'admin'); ?>
    <?php endif; ?>

    <div style="margin-top:auto;padding-top:12px;">
      <a href="logout.php" class="nav-link"><span class="ni">🚪</span><span>Logout</span></a>
    </div>
  </div>
  <div class="nav-footer">
    <div class="nav-user">
      <div class="nav-avatar">👤</div>
      <div>
        <div class="nav-uname"><?=e($uname)?></div>
        <div class="nav-urole"><?=strtoupper(e($role))?></div>
      </div>
    </div>
  </div>
</aside>
<div class="main">
  <div class="topbar">
    <div class="topbar-left">
      <span style="font-size:18px;"><?=e($pIcon)?></span>
      <div>
        <div class="topbar-title"><?=e($pTitle)?></div>
        <div class="topbar-sub"><?=date('l, F j, Y')?></div>
      </div>
    </div>
    <div class="topbar-right">
      <span class="badge <?=$role==='admin'?'b-amber':'b-mint'?>"><?=strtoupper($role)?></span>
      <a href="logout.php" class="btn btn-ghost btn-sm">🚪 Logout</a>
    </div>
  </div>
  <main class="page-content">
