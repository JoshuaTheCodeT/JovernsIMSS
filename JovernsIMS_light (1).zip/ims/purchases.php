<?php require_once 'header.php'; checkAdmin();
$msg=$_GET['msg']??'';

if(isset($_POST['action'])&&$_POST['action']==='add'){csrf_verify();
  $pid=(int)$_POST['product_id']; $cid=($_POST['customer_id']!==''?(int)$_POST['customer_id']:'NULL');
  $qty=(int)$_POST['quantity']; $dt=esc($conn,$_POST['date']??date('Y-m-d'));
  $disc=(float)($_POST['discount']??0); $notes=esc($conn,$_POST['notes']??'');
  $prod=mysqli_fetch_assoc(mysqli_query($conn,"SELECT price,stock FROM products WHERE id=$pid"));
  if(!$prod||$qty<1||$qty>$prod['stock']){header('Location: purchases.php?msg=❌ Invalid quantity.');exit;}
  $orig=$prod['price']*$qty; $cost=max(0,$orig-$disc);
  mysqli_query($conn,"INSERT INTO purchases(product_id,customer_id,quantity,original_cost,cost,discount,date,status,notes,created_by)VALUES($pid,$cid,$qty,$orig,$cost,$disc,'$dt','Pending','$notes','admin')");
  mysqli_query($conn,"UPDATE products SET stock=stock-$qty WHERE id=$pid");
  mysqli_query($conn,"INSERT INTO stock_logs(product_id,change_type,quantity,date)VALUES($pid,'sale',$qty,'$dt')");
  header('Location: purchases.php?msg=✅ Order saved.'); exit;
}
if(isset($_POST['action'])&&$_POST['action']==='status'){csrf_verify();
  $oid=(int)$_POST['oid']; $ns=esc($conn,$_POST['status']??'');
  $cur=mysqli_fetch_assoc(mysqli_query($conn,"SELECT * FROM purchases WHERE id=$oid"));
  mysqli_query($conn,"UPDATE purchases SET status='$ns' WHERE id=$oid");
  if($ns==='Delivered'&&$cur['status']!=='Delivered'){
    mysqli_query($conn,"INSERT INTO sales(purchase_id,product_id,quantity,total_price,date)VALUES({$cur['id']},{$cur['product_id']},{$cur['quantity']},{$cur['cost']},'{$cur['date']}')");
    $sid=mysqli_insert_id($conn);
    mysqli_query($conn,"INSERT INTO payments(sale_id,payment_method,amount,date)VALUES($sid,'Cash',{$cur['cost']},'{$cur['date']}')");}
  header('Location: purchases.php?msg=✅ Status updated.'); exit;
}

$prodsQ=mysqli_query($conn,"SELECT id,name,price,stock,material_cost,labor_cost FROM products WHERE stock>0 ORDER BY name");
$prods=[]; while($p=mysqli_fetch_assoc($prodsQ))$prods[]=$p;
$custQ=mysqli_query($conn,"SELECT id,customer_name FROM customers ORDER BY customer_name");
// product materials for preview
$pmAll=[];
$pmR=mysqli_query($conn,"SELECT pm.product_id,m.material_name,m.supplier,m.price,pm.qty FROM product_materials pm JOIN materials m ON m.material_id=pm.material_id ORDER BY m.material_name");
while($r=mysqli_fetch_assoc($pmR))$pmAll[$r['product_id']][]=$r;

$active=mysqli_query($conn,"SELECT pu.*,p.name pname,c.customer_name FROM purchases pu JOIN products p ON pu.product_id=p.id LEFT JOIN customers c ON pu.customer_id=c.id WHERE pu.status NOT IN('Delivered') ORDER BY pu.id DESC");
?>
<div class="page-header">
  <div class="page-title-block"><h1>🛒 Equipment Orders</h1><p>Create orders, view full quotation, update fabrication status.</p></div>
</div>
<?php if($msg): ?><div class="alert alert-success"><?=e($msg)?></div><?php endif; ?>

<div class="card">
  <div class="card-head"><div class="card-head-icon">📝</div>
    <div><div class="card-head-title">New Equipment Order</div>
    <div class="card-head-sub">Select equipment → full quotation shown automatically</div></div>
  </div>
  <div class="card-body">
  <form method="post">
    <?=csrf_field()?>
    <input type="hidden" name="action" value="add">
    <div class="field-grid">
      <div class="field"><label>Equipment *</label>
        <select name="product_id" id="pSel" required onchange="onProd()">
          <option value="">— Select Equipment —</option>
          <?php foreach($prods as $p): ?>
          <option value="<?=$p['id']?>" data-price="<?=$p['price']?>" data-stock="<?=$p['stock']?>"><?=e($p['name'])?> (Stock: <?=$p['stock']?>)</option>
          <?php endforeach; ?>
        </select></div>
      <div class="field"><label>Client</label>
        <select name="customer_id">
          <option value="">Walk-in / No Client</option>
          <?php while($c=mysqli_fetch_assoc($custQ)): ?>
          <option value="<?=$c['id']?>"><?=e($c['customer_name'])?></option>
          <?php endwhile; ?>
        </select></div>
      <div class="field"><label>Quantity *</label>
        <select name="quantity" id="qtySel" required onchange="calc2()"><option value="">— Select Equipment First —</option></select></div>
      <div class="field"><label>Date *</label>
        <input type="date" name="date" value="<?=date('Y-m-d')?>" required></div>
      <div class="field"><label>Discount (₱)</label>
        <input type="number" step="0.01" name="discount" id="discInput" value="0" min="0" oninput="calc2()"></div>
      <div class="field"><label>Notes</label>
        <input type="text" name="notes" placeholder="Special instructions…"></div>
    </div>

    <!-- Materials preview -->
    <div id="matPreview" style="display:none;margin-top:14px;">
      <div style="font-size:12px;font-weight:700;color:var(--txt2);text-transform:uppercase;letter-spacing:.8px;margin-bottom:10px;">📦 Materials in this Equipment</div>
      <div class="table-wrap" style="margin-bottom:0;">
        <table><thead><tr><th>Material</th><th>Supplier</th><th>Qty/unit</th><th>Unit Price</th><th>Total Qty</th><th>Total Cost</th></tr></thead>
        <tbody id="matPBody"></tbody></table>
      </div>
    </div>

    <!-- Quotation -->
    <div class="quot-box" id="ordQuot" style="display:none;margin-top:20px;">
      <div class="quot-head">📋 Full Order Quotation</div>
      <div class="quot-body">
        <div class="quot-line"><span class="ql">Equipment Unit Price</span><span class="qv" id="oUnit">₱0.00</span></div>
        <div class="quot-line"><span class="ql">Quantity</span><span class="qv" id="oQty">0</span></div>
        <div class="quot-line"><span class="ql">Subtotal</span><span class="qv" id="oSub">₱0.00</span></div>
        <div class="quot-line"><span class="ql">Discount</span><span class="qv" id="oDisc" style="color:var(--rose)">— ₱0.00</span></div>
      </div>
      <div class="quot-total"><span>💰 TOTAL AMOUNT DUE</span><span id="oTotal">₱0.00</span></div>
    </div>
    <div class="card-foot" style="padding:0;border:none;background:none;margin-top:20px;">
      <button type="submit" class="btn">💾 Save Order</button>
    </div>
  </form>
  </div>
</div>

<!-- Active Orders -->
<h3 style="margin-bottom:12px;">📋 Active Orders</h3>
<div class="table-wrap"><table><thead>
  <tr><th>#</th><th>Client</th><th>Equipment</th><th>Qty</th><th>Total</th><th>Discount</th><th>Date</th><th>Status</th></tr>
</thead><tbody>
<?php while($r=mysqli_fetch_assoc($active)):
  $sc=['Pending'=>'b-amber','Fabricating'=>'b-steel','Quality Check'=>'b-steel','Delivered'=>'b-mint','Repair'=>'b-rose'][$r['status']]??'b-muted';
?>
<tr>
  <td class="mono" style="color:var(--txt3)">#<?=$r['id']?></td>
  <td><?=$r['customer_name']?e($r['customer_name']):'<em style="color:var(--txt3)">Walk-in</em>'?></td>
  <td><?=e($r['pname'])?></td>
  <td><?=(int)$r['quantity']?></td>
  <td class="mono" style="font-weight:700;color:var(--amber)">₱<?=number_format($r['cost'],2)?></td>
  <td class="mono" style="color:var(--rose)"><?=$r['discount']>0?'₱'.number_format($r['discount'],2):'—'?></td>
  <td style="font-size:12px;color:var(--txt3)"><?=date('M j, Y',strtotime($r['date']))?></td>
  <td>
    <form method="post" style="margin:0;">
      <?=csrf_field()?>
      <input type="hidden" name="action" value="status">
      <input type="hidden" name="oid" value="<?=$r['id']?>">
      <select name="status" onchange="this.form.submit()" style="padding:5px 8px;font-size:12px;border-radius:7px;width:auto;">
        <?php foreach(['Pending','Fabricating','Quality Check','Delivered','Repair'] as $s): ?>
        <option value="<?=$s?>" <?=$r['status']===$s?'selected':''?>><?=$s?></option>
        <?php endforeach; ?>
      </select>
    </form>
  </td>
</tr>
<?php endwhile; ?>
</tbody></table></div>

<script>
const pmAll=<?=json_encode($pmAll)?>;
const fmt=v=>'₱'+parseFloat(v).toLocaleString('en-PH',{minimumFractionDigits:2,maximumFractionDigits:2});

function onProd(){
  const sel=document.getElementById('pSel');
  const opt=sel.options[sel.selectedIndex];
  const pid=sel.value; const stock=parseInt(opt?.dataset?.stock||0);
  const price=parseFloat(opt?.dataset?.price||0);
  const qSel=document.getElementById('qtySel');
  qSel.innerHTML='<option value="">— Qty —</option>';
  for(let i=1;i<=stock;i++) qSel.innerHTML+=`<option value="${i}">${i} unit${i>1?'s':''}</option>`;
  const mats=pmAll[pid]||[];
  const tb=document.getElementById('matPBody'); tb.innerHTML='';
  if(mats.length){
    mats.forEach(m=>{tb.innerHTML+=`<tr><td><strong>${m.material_name}</strong></td><td style="color:var(--txt2);font-size:12px">🏭 ${m.supplier}</td><td style="text-align:center">${m.qty}</td><td class="mono">${fmt(m.price)}</td><td class="mono mat-tq" data-qty="${m.qty}" style="text-align:center">—</td><td class="mono mat-tc" data-price="${m.price}" data-matqty="${m.qty}">—</td></tr>`;});
    document.getElementById('matPreview').style.display='block';
  } else document.getElementById('matPreview').style.display='none';
  calc2();
}
function calc2(){
  const pSel=document.getElementById('pSel'); const opt=pSel.options[pSel.selectedIndex];
  const qty=parseInt(document.getElementById('qtySel').value)||0;
  const disc=parseFloat(document.getElementById('discInput').value)||0;
  const price=parseFloat(opt?.dataset?.price||0);
  if(!pSel.value||qty<1){document.getElementById('ordQuot').style.display='none';return;}
  const sub=price*qty; const total=Math.max(0,sub-disc);
  document.getElementById('oUnit').textContent=fmt(price);
  document.getElementById('oQty').textContent=qty+' unit'+(qty>1?'s':'');
  document.getElementById('oSub').textContent=fmt(sub);
  document.getElementById('oDisc').textContent='— '+fmt(disc);
  document.getElementById('oTotal').textContent=fmt(total);
  document.querySelectorAll('.mat-tq').forEach(c=>{const mq=parseInt(c.dataset.qty);c.textContent=(mq*qty)+' pcs';});
  document.querySelectorAll('.mat-tc').forEach(c=>{const mp=parseFloat(c.dataset.price);const mq=parseInt(c.dataset.matqty);c.textContent=fmt(mp*mq*qty);});
  document.getElementById('ordQuot').style.display='block';
}
</script>
<?php require_once 'footer.php'; ?>
