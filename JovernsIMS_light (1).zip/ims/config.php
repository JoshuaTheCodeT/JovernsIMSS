<?php
// ═══════════════════════════════════════════════════════
//  Jovern's Fabricating Shop — IMS  |  config.php
//  Security: CSRF tokens, HttpOnly sessions, bcrypt
// ═══════════════════════════════════════════════════════
$host = 'localhost'; $db = 'inventory_db'; $user = 'root'; $pass = '';

if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params(['lifetime'=>0,'path'=>'/','httponly'=>true,'samesite'=>'Strict']);
    session_start();
}

$conn = mysqli_connect($host, $user, $pass, $db);
if (!$conn) die('DB connection failed: '.mysqli_connect_error());
mysqli_set_charset($conn,'utf8mb4');
date_default_timezone_set('Asia/Manila');

// CSRF
function csrf_token():string {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}
function csrf_field():string { return '<input type="hidden" name="csrf" value="'.csrf_token().'">'; }
function csrf_verify():void {
    if (!hash_equals($_SESSION['csrf']??'', $_POST['csrf']??'')) {
        http_response_code(403); die('<h2>403 — CSRF token mismatch. Go back and try again.</h2>');
    }
}

// Sanitise output
function e(string $v):string { return htmlspecialchars($v, ENT_QUOTES, 'UTF-8'); }
// Safe DB string
function esc($conn,string $v):string { return mysqli_real_escape_string($conn, trim($v)); }
